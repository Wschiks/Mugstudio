<?php
/**
 * Dobbel theme functions.
 */

if ( ! defined( 'ABSPATH' ) ) {
    exit; // no direct access
}

function dobbel_setup() {
    // lets WordPress build the <title> tag for us (used via wp_head() in header.php)
    add_theme_support( 'title-tag' );
    // adds featured-image support, in case you want to use it later
    add_theme_support( 'post-thumbnails' );
}
add_action( 'after_setup_theme', 'dobbel_setup' );

function dobbel_enqueue_styles() {
    wp_enqueue_style(
        'dobbel-style',
        get_stylesheet_uri(),
        array(),
        wp_get_theme()->get( 'Version' )
    );
}
add_action( 'wp_enqueue_scripts', 'dobbel_enqueue_styles' );